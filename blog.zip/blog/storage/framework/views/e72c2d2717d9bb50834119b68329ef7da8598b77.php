<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                             <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
               		
                     <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger">
                             <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                  	 <form method="post" action="/rss">
					 	<?php					
					 	@csrf
					 	?>	
					 			
					  <input type="text" name="feedurl" placeholder="Enter website feed URL">&nbsp;<input type="submit" value="Submit" name="submit">
					 </form>
					 
					 <?php
												 
					 foreach ($feeds as $feed) {
					 	//var_dump($feed);
						 if(@simplexml_load_file($feed->url)){
						  $feedData = simplexml_load_file($feed->url);
						 }else{
						  $invalidurl = true;
						  echo "<h2>Invalid RSS feed URL.</h2>";
						 }
						 
						 
						 $i=0;
						 if(!empty($feedData)){
						
						  $site = $feedData->channel->title;
						  $sitelink = $feedData->channel->link;
						  $imagelink = $feedData->channel->image->url;
							
						  echo "<h2><a href='".route('feed',[ 'feed_id'=>$feed->id])."'>".$site."</a></h2>";
						  echo "<img width='200px' src='".$imagelink."' ></h2>";
						  foreach ($feedData->channel->item as $item) {
						
						   $title = $item->title;
						   $link = $item->link;
						   $description = $item->description;
						   $postDate = $item->pubDate;
						   $pubDate = date('D, d M Y',strtotime($postDate));
						
						
						   if($i>=5) break;
						  ?>
						   <div class="post">
						     <div class="post-head">
						       <h2 class="feed_title" ><?php echo $title; ?></h2>
						       <span><?php echo $pubDate; ?></span>
						     </div>
						     <div class="post-content">
						       <?php echo $description; ?>
						     </div>
						   </div>
						
						   <?php
						    $i++;
						   }
						 }
						 
						 
						 
						 
						 
					 }

					 /*
					 
					  foreach ($feeds as $feed) {
					  	echo $feed->url;
						  $url = $feeds->url;
						//showRss($feed->url);
					 }
					  */
					 /*
					 if(isset($_POST['submit'])){
					   if($_POST['feedurl'] != ''){
					     $url = $_POST['feedurl'];
					   }
					 }
						
					 foreach ($feeds as $url) {
					 }
					*/
				function showRss(){
					if(!empty( $url)){
					 $invalidurl = false;
					 if(@simplexml_load_file($url)){
					  $feeds = simplexml_load_file($url);
					 }else{
					  $invalidurl = true;
					  echo "<h2>Invalid RSS feed URL.</h2>";
					 }
					}
					 					 				
					 $i=0;
					 if(!empty($feeds)){
					
					  $site = $feeds->channel->title;
					  $sitelink = $feeds->channel->link;
					
					  echo "<h2>".$site."</h2>";
					  foreach ($feeds->channel->item as $item) {
					
					   $title = $item->title;
					   $link = $item->link;
					   $description = $item->description;
					   $postDate = $item->pubDate;
					   $pubDate = date('D, d M Y',strtotime($postDate));
					
					
					   if($i>=5) break;
					  ?>
					   <div class="post">
					     <div class="post-head">
					       <h2><a class="feed_title" href="<?php echo $link; ?>"><?php echo $title; ?></a></h2>
					       <span><?php echo $pubDate; ?></span>
					     </div>
					     <div class="post-content">
					       <?php echo implode(' ', array_slice(explode(' ', $description), 0, 20)) . "..."; ?> <a href="<?php echo $link; ?>">Read more</a>
					     </div>
					   </div>
					
					   <?php
					    $i++;
					   }
					 }else{
					   if(!$invalidurl){
					     echo "<h2>No item found</h2>";
					   }
					 }
					 
					 
					 }
					 ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>