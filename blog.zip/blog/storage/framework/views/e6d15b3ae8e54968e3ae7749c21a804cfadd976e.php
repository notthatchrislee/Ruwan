<?php $__env->startSection('content'); ?>
<div class="container">
	 <a href="/home" class="btn btn-outline-primary btn-sm">Go Home</a>
    <div class="row">
        <div class="col-md-12">
        <h1 class="display-4">Blogs</h1>
               
    
					<?php																						 
					 foreach ($posts as $post) {					 	 
						echo "<h2>" . $post->blogpost_title . "</h2>";
						echo $post->blogpost_author;					  
						echo $post->blogpost_content;
					?>
						<form action='<?php echo e(route('blogpost.view', $post->id)); ?>' method='POST'>		 	
					 	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
						 
							<button id='btn-edit' class='btn btn-primary'>
                                    View Post
                        	</button>
						</form>
					<?php
					 }					 						 					 
					?>
						 
                <br />
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>