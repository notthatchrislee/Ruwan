<?php $__env->startSection('content'); ?>
<div class="container">
	 <a href="/" class="btn btn-outline-primary btn-sm">Blogs</a>
    <div class="row">
        <div class="col-md-12">
         <h1 class="display-4">Home</h1>
              
            <div class="container">
                <?php if(session('status')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                  </div>
                <?php endif; ?>
 				<?php																						 
			 	foreach ($posts as $post) {				 		
		 		?>
				<h2> <?php echo $post->blogpost_title ?></h2>					 		 
				 <div class="row justify-content-start">
					<div class="col-md-1">
						<form action='<?php echo e(route('blogpost.edit', $post->id)); ?>' method='POST'>		 	
					 	 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 	 
							<button id='btn-edit' class='btn btn-primary'>
                                    Edit Post
                             </button>
						</form>
				 	</div>			 		 
					<div class="col-md-1">
						<form action='<?php echo e(route('blogpost.destroy', $post->id)); ?>' method='POST'>		 	
						 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 	 
							<button id='btn-delete' class='btn btn-primary'>
                              Delete Post
               	         </button>
						</form>
					</div>
					 	
		 		</div>
					 	
				<?php			 
					 }					 						 					 
				?>
                   
                </div>
               </br />
                
                <div class="panel panel-default">
                <div class="panel-heading">Add Blog</div>
                 <form action="<?php echo e(route('blogpost.create')); ?>" method="POST">              	
                       <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">           
                        <div class="" style="padding:20px;">
                            <div class="control-group col-12">
                                <label for="title">Post Title</label>
                                <input type="text" id="title" class="form-control" name="title"
                                       placeholder="Enter Post Title" required>
                            </div>
                            <div class="control-group col-12 mt-2">
                                <label for="body">Post Body</label>
                                <textarea id="body" class="form-control" name="body" placeholder="Enter Post Body"
                                          rows=""></textarea>
                            </div>
                        </div>
                        <div class="row m-2" style="padding:20px;">
                            <div class="control-group col-12 text-center">
                                <button id="btn-submit" class="btn btn-primary">
                                    Create Post
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                
<script>
	    
      tinymce.init({
        selector: '#body',
        plugins: [
          'a11ychecker','advlist','advcode','advtable','autolink','checklist','export',
          'lists','link','image','charmap','preview','anchor','searchreplace','visualblocks',
          'powerpaste','fullscreen','formatpainter','insertdatetime','media','table','help','wordcount'
        ],
        toolbar: 'undo redo | formatpainter casechange blocks | bold italic backcolor | ' +
          'alignleft aligncenter alignright alignjustify | ' +
          'bullist numlist checklist outdent indent | removeformat | a11ycheck code table help'
      });
  
	
</script>

          
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>