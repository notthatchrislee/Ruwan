<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class BlogPost extends Model
{
    //
     protected $table = 'blogposts';
     	protected $fillable = [
     		'blogpost_title',
             'blogpost_content',
             'user_id',
             'blogpost_author'       
         ];
		 
		 
		  public function user()
		{
		    return $this->belongsTo('App\User');
		}

		 
		 public function blogcomment()
	    {
	        return $this->hasMany('App\BlogComment');
	    }
}
