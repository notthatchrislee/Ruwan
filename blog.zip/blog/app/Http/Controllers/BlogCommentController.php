<?php

namespace App\Http\Controllers;

use Session;
use App\BlogPost;
use App\BlogComment;
use Illuminate\Http\Request;



class BlogCommentController extends Controller
{
	/**
     * Create a new controller instance.
     *
     * @return void
     */
     


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function index(){
	
	}
	
	/*
	 * add comments to blog
	 * */
	public function create(Request $request){
		
			$blogid = $request->post_id;
			
			//set new comment data
			$newBlogComment = new BlogComment;
			$newBlogComment->blogcomment_name = $request->name;
			$newBlogComment->blogcomment_content = $request->body;			
			$newBlogComment->blogpost_id = $blogid;
			$newBlogComment->save();	
			
			//return page view
			return redirect()->route('blogpost.view', $blogid)->with('status', 'Comment added');
			
	}
	
	public function store(){
		
	}
	

	
	
	


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
     
   
  

	
	
}
