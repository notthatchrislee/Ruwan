<?php

namespace App\Http\Controllers;

use Session;
use App\BlogPost;
use App\BlogComment;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class BlogPostController extends Controller
{
	
	/*
	 * view all blogs
	 * */
	 
	public function index(){
	$posts = Blog::all();
	}
	
	
	/*
	 * add new blog
	 * */
	 
	public function create(Request $request){
		
			//get user id
			$id = Auth::id();			
			$author = User::find($id);
			
			//set new blog data
			$newBlogPost = new BlogPost;
			$newBlogPost->blogpost_title = $request->title;
			$newBlogPost->blogpost_content = $request->body;
			$newBlogPost->user_id = $id;
			$newBlogPost->blogpost_author = $author->name;			
			$newBlogPost->save();	
			
			// return web page
			return redirect()->route('home')->with('status', 'Blog added');
	}
	
	public function store(){
		
	}
	
	
	/*
	 * get individual blog
	 * */
	 
	public function show(int $post_id){
		
		//get comments
		$comments = BlogComment::whereRaw('blogpost_id  = 1', [25])->get();
		
		//get blog
		$post = new BlogPost;
		$post = BlogPost::find($post_id);
		
		//add comments
		$post['blogcomments'] = $comments;
			
		//return page view
		return view('blog_view', [
		"post" => $post,
		]); 
		 
	}
	
	/*
	 * get individual blog for edit
	 * */
	 
	public function edit(int $post_id){
		
		//get blog
		$post = new BlogPost;
		$post = BlogPost::find($post_id);	
			
		//returns page view		
		return view('blog_edit', [
		"post" => $post,
		]); 
		
	
	}
	
	
	/*
	 * set updated blog
	 * */
	 
	public function update(Request $request){
		
			//set updated blog data
			$newpost = new BlogPost;
			$post = BlogPost::find($request->id);
			$post->blogpost_title = $request->title;
			$post->blogpost_content = $request->body;		
			$post->save();	

			//return page view
			return redirect()->route('home')->with('status', 'Blog updated');
	}
	
	/*
	 * delete blog
	 * */
	 
	public function destroy(int $post_id){
		
		//get and delete blog
		$post = BlogPost::find($post_id);
		$post->delete();
		
		//return page view
		return redirect()->route('home')->with('status', 'Blog deleted');
	}

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
     
 

	
	
}
