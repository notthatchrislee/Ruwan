<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BlogPost;

class IndexController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
     


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    	 //$id = Auth::id();
		//$posts = BlogPost::all();
		//var_dump($userFeeds);
		
    	$posts = BlogPost::all(); //fetch all blog posts from DB
    	//var_dump($posts);
		return view('/index', [
           'posts' => $posts,
      	 ]); //returns the view with posts
		
        //return view('/index');
    }
}
