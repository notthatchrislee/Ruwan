<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class BlogComment extends Model
{
    //
     protected $table = 'blogcomments';
     	protected $fillable = [
     		'blogcomment_name',
             'blogcomment_content',
             'blogpost_id' 
         ];
		 
		 
		 public function blogpost()
		{
		    return $this->belongsTo('App\BlogPost');
		}
}
