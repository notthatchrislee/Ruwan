<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', 'IndexController@index')->name('index');

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/login', 'HomeController@index')->name('home');
Auth::routes();

Route::post('/blogpost/create', 'BlogPostController@create')->name('blogpost.create');
Auth::routes();

Route::post('/blogpost/destroy/{post_id}', 'BlogPostController@destroy')->name('blogpost.destroy');
Auth::routes();

Route::post('/blogpost/edit/{post_id}', 'BlogPostController@edit')->name('blogpost.edit');
Auth::routes();

Route::post('/blogpost/update', 'BlogPostController@update')->name('blogpost.update');
Auth::routes();

Route::post('/blogpost/view/{post_id}', 'BlogPostController@show')->name('blogpost.view');
Route::get('/blogpost/view/{post_id}', 'BlogPostController@show')->name('blogpost.view');

Route::post('/blogcomment/create', 'BlogCommentController@create')->name('blogcomment.create');

