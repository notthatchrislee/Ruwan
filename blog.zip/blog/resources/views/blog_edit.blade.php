@extends('layouts.app')

@section('content')
   
    <div class="container">
        <div class="row">
            <div class="col-12">
                <a href="/home" class="btn btn-outline-primary btn-sm">Go back</a>
                <div class="">
                    <h1 class="display-4">Edit Post</h1>
                 

                    <hr>
					<div class="container">
                    <form action="{{route('blogpost.update')}}" method="POST">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
                        <input type="hidden" id="post_id" name="id" value="{{ $post->id }}">
                    
                        <div class="row">
                            <div class="control-group col-12">
                                <label for="title">Post Title</label>
                                <input type="text" id="title" class="form-control" name="title"
                                       placeholder="Enter Post Title" value="{{ $post->blogpost_title }}" required>
                            </div>
                            <div class="control-group col-12 mt-2">
                                <label for="body">Post Body</label>
                                <textarea id="body" class="form-control" name="body" placeholder="Enter Post Body"
                                          rows="5" required>{{ $post->blogpost_content }}</textarea>
                            </div>
                        </div>
                        <div class="row" style="padding:20px;">
                            <div class="control-group col-12 text-center">
                                <button id="btn-submit" class="btn btn-primary">
                                    Update Post
                                </button>
                            </div>
                        </div>
                    </form>
                    
                   </div>
                </div>
                
                
 <script>
	    
      tinymce.init({
        selector: '#body',
        plugins: [
          'a11ychecker','advlist','advcode','advtable','autolink','checklist','export',
          'lists','link','image','charmap','preview','anchor','searchreplace','visualblocks',
          'powerpaste','fullscreen','formatpainter','insertdatetime','media','table','help','wordcount'
        ],
        toolbar: 'undo redo | formatpainter casechange blocks | bold italic backcolor | ' +
          'alignleft aligncenter alignright alignjustify | ' +
          'bullist numlist checklist outdent indent | removeformat | a11ycheck code table help'
      });
  
	
</script>

            </div>
        </div>
    </div>

@endsection