@extends('layouts.app')

@section('content')
<div class="container">
	 <a href="/home" class="btn btn-outline-primary btn-sm">Go Home</a>
    <div class="row">
        <div class="col-md-12">
        <h1 class="display-4">Blogs</h1>
               
    
					<?php																						 
					 foreach ($posts as $post) {					 	 
						echo "<h2>" . $post->blogpost_title . "</h2>";
						echo $post->blogpost_author;					  
						echo $post->blogpost_content;
					?>
						<form action='{{route('blogpost.view', $post->id)}}' method='POST'>		 	
					 	<input type="hidden" name="_token" value="{{ csrf_token() }}"> 
						 
							<button id='btn-edit' class='btn btn-primary'>
                                    View Post
                        	</button>
						</form>
					<?php
					 }					 						 					 
					?>
						 
                <br />
               
            </div>
        </div>
    </div>
</div>
@endsection