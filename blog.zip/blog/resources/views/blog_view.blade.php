@extends('layouts.app')

@section('content')
   
    <div class="container">
    	 <a href="/" class="btn btn-outline-primary btn-sm">Go Back</a>
        <div class="">
            <div class="col-12 pt-2">         
                <div class="border rounded mt-5 pl-4 pr-4 pt-4 pb-4">
                
                    <?php
                      echo "<h2>" . $post->blogpost_title . "</h2>";
						echo $post->blogpost_author;					  
						echo $post->blogpost_content;					  
					 ?>

                    <hr>                 
                </div>

            </div>           
            <div>
            	
            <h3>Comments</h3>           						 		
				<?php																						 
					foreach ($post->blogcomments as $comment) {
					 	echo'<div class="panel panel-default" style="padding:20px;">';
					 	echo  $comment->blogcomment_name;
					 	echo  '<p>'.$comment->blogcomment_content .'</p>';
						echo '</div>';			 		
					}
				?>           	
            </div>
            
            
             <div class="">Add Comment</div>
                 <form action="{{route('blogcomment.create')}}" method="POST">               	
                       <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <input type="hidden" name="post_id" value="{{ $post->id }}">
                        <div class="">
                            <div class="control-group col-12">
                                <label for="name">Username</label>
                                <input type="text" id="name" class="form-control" name="name"
                                       placeholder="Enter Username" required>
                            </div>
                            <div class="control-group col-12 mt-2">
                                <label for="body">Comment</label>
                                <textarea id="body" class="form-control" name="body" placeholder="Enter Post Body"
                                          rows="" required></textarea>
                            </div>
                        </div>
                        <div class="row" style="padding:20px;">
                            <div class="control-group col-12 text-center">
                                <button id="btn-submit" class="btn btn-primary">
                                    Create Comment
                                </button>
                            </div>
                        </div>
                    </form>
            
            
        </div>
    </div>

@endsection